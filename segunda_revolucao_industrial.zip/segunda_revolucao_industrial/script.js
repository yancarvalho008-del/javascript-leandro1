// Seleciona todos os cartões de invenções e os elementos do painel de detalhes.
const cartoes = document.querySelectorAll('.cartao');
const tituloDetalhe = document.querySelector('#detalhe-titulo');
const textoDetalhe = document.querySelector('#detalhe-texto');

// Ao clicar em um cartão, mostra a explicação correspondente.
cartoes.forEach(function(cartao) {
  cartao.addEventListener('click', function() {
    cartoes.forEach(function(item) {
      item.classList.remove('ativo');
    });

    cartao.classList.add('ativo');
    tituloDetalhe.textContent = cartao.dataset.titulo;
    textoDetalhe.textContent = cartao.dataset.detalhe;
  });
});

// Mostra ou esconde a curiosidade quando o botão é clicado.
const botaoCuriosidade = document.querySelector('#botao-curiosidade');
const curiosidade = document.querySelector('#curiosidade');

botaoCuriosidade.addEventListener('click', function() {
  if (curiosidade.hidden) {
    curiosidade.hidden = false;
    botaoCuriosidade.textContent = 'Esconder curiosidade';
  } else {
    curiosidade.hidden = true;
    botaoCuriosidade.textContent = 'Mostrar uma curiosidade';
  }
});
